package com.venom.minecraftmanager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class MinecraftManagerPlugin extends JavaPlugin {
    private static final String ADMIN = "minecraftmanager.admin";
    private static final String KIT_PERMISSION = "minecraftmanager.kit";

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("MinecraftManager enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        switch (name) {
            case "manager" -> {
                if (!isAdmin(sender)) return noPermission(sender);
                if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                    send(sender, "&bMinecraftManager &7commands:");
                    send(sender, "&f/manager reload &7- reload config");
                    send(sender, "&f/manager givekit <player> &7- give starter kit");
                    send(sender, "&f/manager addmoney <player> <amount> &7- add coins");
                    send(sender, "&f/manager setrank <player> <rank> &7- set rank");
                    send(sender, "&f/tp <player> &7- teleport to player (admin)");
                    send(sender, "&f/tphere <player> &7- bring player (admin)");
                    return true;
                }
                if (args[0].equalsIgnoreCase("reload")) {
                    reloadConfig();
                    send(sender, "&aConfiguration reloaded.");
                    return true;
                }
                if (args[0].equalsIgnoreCase("givekit") && args.length >= 2) {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) { send(sender, "&cThat player is not online."); return true; }
                    giveConfiguredKit(target, "starter-kit.items");
                    send(sender, "&aStarter kit given to &f" + target.getName() + "&a.");
                    return true;
                }
                if (args[0].equalsIgnoreCase("addmoney") && args.length >= 3) {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    double amount = parseAmount(args[2]);
                    if (target == null || amount <= 0) { send(sender, "&cUsage: /manager addmoney <online-player> <positive-amount>"); return true; }
                    setBalance(target.getUniqueId(), getBalance(target.getUniqueId()) + amount);
                    send(sender, "&aAdded " + formatMoney(amount) + " to " + target.getName() + ".");
                    send(target, "&aYou received " + formatMoney(amount) + ".");
                    return true;
                }
                if (args[0].equalsIgnoreCase("setrank") && args.length >= 3) {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    String rank = normalizeRank(args[2]);
                    if (target == null || rank == null) { send(sender, "&cUsage: /manager setrank <online-player> <PLAYER|YOUTUBER|INSTA|HELPER|STAFF|ADMIN|MANAGER|DEVELOPER|CO-OWNER|OWNER>"); return true; }
                    getConfig().set("player-ranks." + target.getUniqueId(), rank);
                    saveConfig();
                    send(sender, "&aSet " + target.getName() + "'s rank to &f" + rank + "&a.");
                    send(target, "&aYour rank is now &f" + rank + "&a.");
                    return true;
                }
                send(sender, "&cUnknown command. Use /manager help.");
                return true;
            }
            case "kit" -> {
                if (!(sender instanceof Player player)) { send(sender, "&cOnly players can use kits."); return true; }
                String kit = args.length == 0 ? "starter" : args[0].toLowerCase(Locale.ROOT);
                if (kit.equals("starter")) {
                    if (!player.hasPermission(KIT_PERMISSION) && !isAdmin(player)) return noPermission(sender);
                    String path = "claimed-kits." + player.getUniqueId();
                    if (getConfig().getBoolean("starter-kit.one-time", true) && getConfig().getBoolean(path, false) && !isAdmin(player)) {
                        send(player, getConfig().getString("messages.kit-already-claimed", "&eAlready claimed."));
                        return true;
                    }
                    giveConfiguredKit(player, "starter-kit.items");
                    if (getConfig().getBoolean("starter-kit.one-time", true)) {
                        getConfig().set(path, true);
                        saveConfig();
                    }
                    send(player, getConfig().getString("messages.kit-claimed", "&aKit received!"));
                    return true;
                }
                send(player, "&cStaff ranks are not kits. Use /kit for the starter kit.");
                return true;
            }
            case "buykit" -> {
                send(sender, "&cStaff ranks (PLAYER, MANAGER, OWNER) cannot be purchased in-game.");
                send(sender, "&7An existing admin can assign them with /manager setrank <player> <PLAYER|MANAGER|OWNER>.");
                return true;
            }
            case "rank" -> {
                if (args.length == 0) {
                    if (!(sender instanceof Player player)) { send(sender, "&cUse /rank <player> from console."); return true; }
                    send(player, "&7Your rank: &b" + getRank(player.getUniqueId()));
                    return true;
                }
                if (args.length == 1 && sender.hasPermission(ADMIN)) {
                    Player target = Bukkit.getPlayerExact(args[0]);
                    if (target == null) { send(sender, "&cThat player is not online."); return true; }
                    send(sender, "&7" + target.getName() + "'s rank: &b" + getRank(target.getUniqueId()));
                    return true;
                }
                send(sender, "&cUsage: /rank" + (isAdmin(sender) ? " [player]" : ""));
                return true;
            }
            case "balance" -> {
                if (!(sender instanceof Player player)) { send(sender, "&cOnly players can check balance."); return true; }
                send(player, "&7Balance: &e" + formatMoney(getBalance(player.getUniqueId())));
                return true;
            }
            case "tp" -> {
                if (!isAdmin(sender)) return noPermission(sender);
                if (!(sender instanceof Player player)) { send(sender, "&cConsole: use /tp <player> only in-game."); return true; }
                if (args.length != 1) { send(sender, "&cUsage: /tp <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { send(sender, "&cThat player is not online."); return true; }
                player.teleport(target.getLocation());
                send(player, "&aTeleported to &f" + target.getName() + "&a.");
                return true;
            }
            case "tphere" -> {
                if (!isAdmin(sender)) return noPermission(sender);
                if (!(sender instanceof Player player)) { send(sender, "&cConsole cannot use /tphere."); return true; }
                if (args.length != 1) { send(sender, "&cUsage: /tphere <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { send(sender, "&cThat player is not online."); return true; }
                target.teleport(player.getLocation());
                send(player, "&aBrought &f" + target.getName() + " &ato you.");
                send(target, "&eAn admin teleported you.");
                return true;
            }
            case "heal", "feed", "gmc" -> {
                if (!isAdmin(sender)) return noPermission(sender);
                Player target = targetOrSelf(sender, args);
                if (target == null) return true;
                if (name.equals("heal")) {
                    target.setHealth(target.getMaxHealth());
                    target.setFireTicks(0);
                    send(sender, "&aHealed &f" + target.getName() + "&a.");
                } else if (name.equals("feed")) {
                    target.setFoodLevel(20);
                    target.setSaturation(20f);
                    send(sender, "&aFed &f" + target.getName() + "&a.");
                } else {
                    target.setGameMode(GameMode.CREATIVE);
                    send(sender, "&aSet &f" + target.getName() + "&a to Creative mode.");
                }
                if (target != sender) send(target, "&aAn admin used " + name + " on you.");
                return true;
            }
            default -> { return false; }
        }
    }

    private void giveConfiguredKit(Player player, String path) {
        ConfigurationSection section = getConfig().getConfigurationSection(path);
        if (section == null) { send(player, "&cThis kit has no items configured."); return; }
        for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key);
            if (material == null || !material.isItem()) {
                getLogger().warning("Invalid kit material at " + path + ": " + key);
                continue;
            }
            int amount = section.getInt(key, 1);
            if (amount <= 0) continue;
            int remaining = amount;
            while (remaining > 0) {
                int stackAmount = Math.min(remaining, material.getMaxStackSize());
                ItemStack item = new ItemStack(material, stackAmount);
                Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item);
                leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
                remaining -= stackAmount;
            }
        }
    }

    private Player targetOrSelf(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player player) return player;
            send(sender, "&cFrom console, specify a player name.");
            return null;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) send(sender, "&cThat player is not online.");
        return target;
    }

    private double parseAmount(String raw) {
        try { double n = Double.parseDouble(raw); return Double.isFinite(n) && n > 0 ? n : -1; }
        catch (NumberFormatException ex) { return -1; }
    }

    private double getBalance(UUID uuid) {
        return getConfig().getDouble("balances." + uuid, getConfig().getDouble("economy.starting-balance", 500));
    }

    private void setBalance(UUID uuid, double amount) {
        getConfig().set("balances." + uuid, Math.max(0, amount));
        saveConfig();
    }

    private String getRank(UUID uuid) {
        return getConfig().getString("player-ranks." + uuid, "DEFAULT").toUpperCase(Locale.ROOT);
    }

    private String normalizeRank(String raw) {
        String rank = raw.toUpperCase(Locale.ROOT);
        return switch (rank) {
            case "PLAYER", "YOUTUBER", "INSTA", "HELPER", "STAFF", "ADMIN",
                 "MANAGER", "DEVELOPER", "DEVLOPER", "CO-OWNER", "CO_OWNER", "COOWNER", "OWNER" -> rank;
            default -> null;
        };
    }

    private int rankLevel(String rank) {
        return switch (rank.toUpperCase(Locale.ROOT)) {
            case "PLAYER" -> 0;
            case "YOUTUBER", "INSTA" -> 1;
            case "HELPER" -> 2;
            case "STAFF" -> 3;
            case "ADMIN" -> 4;
            case "MANAGER" -> 5;
            case "DEVELOPER", "DEVLOPER" -> 6;
            case "CO-OWNER", "CO_OWNER", "COOWNER" -> 7;
            case "OWNER" -> 8;
            default -> -1;
        };
    }

    private String formatMoney(double amount) {
        return String.format(Locale.US, "%.0f coins", amount);
    }

    private boolean isAdmin(CommandSender sender) {
        // OPs always retain emergency access. Otherwise, only OWNER, CO-OWNER,
        // and MANAGER ranks can use management commands.
        if (sender.isOp() || sender.hasPermission(ADMIN)) return true;
        if (!(sender instanceof Player player)) return false;
        String rank = getRank(player.getUniqueId());
        return rank.equals("OWNER") || rank.equals("CO-OWNER")
                || rank.equals("CO_OWNER") || rank.equals("COOWNER")
                || rank.equals("MANAGER");
    }

    private boolean noPermission(CommandSender sender) {
        send(sender, getConfig().getString("messages.no-permission", "&cNo permission."));
        return true;
    }

    private void send(CommandSender sender, String message) {
        String prefix = getConfig().getString("messages.prefix", "&8[&bManager&8] ");
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', (prefix == null ? "" : prefix) + (message == null ? "" : message)));
    }
}
