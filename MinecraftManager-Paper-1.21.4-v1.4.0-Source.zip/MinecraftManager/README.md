# MinecraftManager — Paper 1.21.4 (v1.4.0)

## Rank-based command access

Management commands are available to:
- OWNER
- CO-OWNER
- MANAGER

Console and server operators retain administrative access. Players with `minecraftmanager.admin` also have access, so do not grant that permission to ordinary players.

Basic commands available to all players:
- `/kit` — claim the starter kit (permission `minecraftmanager.kit`)
- `/rank` — view your own rank
- `/balance` — view your coins

Management commands (OWNER / CO-OWNER / MANAGER, operators, or users with `minecraftmanager.admin`):
- `/manager help`
- `/manager reload`
- `/manager givekit <player>`
- `/manager addmoney <online-player> <amount>`
- `/manager setrank <online-player> <rank>`
- `/tp <player>`
- `/tphere <player>`
- `/heal [player]`
- `/feed [player]`
- `/gmc [player]`
- `/rank <online-player>` (view another player's rank)

Supported ranks: PLAYER, YOUTUBER, INSTA, HELPER, STAFF, ADMIN, MANAGER, DEVELOPER, CO-OWNER, OWNER.

Note: the current rank check is applied to management commands. Rank names do not grant unrelated permissions in other plugins. To give OWNER/CO-OWNER/MANAGER access without OP, the rank must be assigned by an operator or an existing manager using `/manager setrank <player> <rank>`.

## Build
Requirements: Java 21 JDK, Maven 3.9+, internet access to download Maven dependencies.
Run in the directory containing `pom.xml`:
```bash
mvn clean package
```
Output: `target/MinecraftManager.jar`

## Install
Stop Paper, copy the JAR into `plugins/`, and restart. Back up the server first.

## Permission nodes
- `minecraftmanager.kit` — default: everyone
- `minecraftmanager.admin` — default: op

This source ZIP has not been compiled or tested in a live Paper server.
